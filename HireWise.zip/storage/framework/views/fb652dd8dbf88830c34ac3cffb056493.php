


<?php $__env->startSection('title', 'Candidate Assessment'); ?>
<?php $__env->startSection('page-title', 'Candidate Assessment'); ?>

<?php $__env->startSection('content'); ?>


<div class="mb-6">
    <h1 class="text-2xl font-bold text-slate-800">Candidate Assessment</h1>
    <p class="mt-1 text-sm text-slate-500">
        Pengisian nilai kandidat berdasarkan kriteria Recruitment Batch.
    </p>
</div>


<div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
    <form method="GET" action="<?php echo e(route('candidate-assessments.index')); ?>">
        <label class="mb-2 block text-sm font-medium text-slate-700">
            Pilih Recruitment Batch
        </label>

        <div class="flex flex-col gap-3 sm:flex-row">
            <select name="batch"
                    class="w-full rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-700 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-100">
                <option value="">-- Pilih Batch --</option>

                <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($batch->id); ?>"
                        <?php if(request('batch') == $batch->id): echo 'selected'; endif; ?>>
                        <?php echo e($batch->batch_code); ?> - <?php echo e($batch->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit"
                    class="rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700">
                Tampilkan
            </button>
        </div>
    </form>
</div>

<?php if($selectedBatch): ?>

    <?php
        $criterionIds = $criteria->pluck('id');

        $completedApplications = $applications->filter(function ($application) use ($criterionIds) {
            return $criterionIds->isNotEmpty()
                && $application->assessments
                    ->whereIn('recruitment_criterion_id', $criterionIds)
                    ->count() === $criterionIds->count();
        });

        $completedCount = $completedApplications->count();
        $incompleteCount = $applications->count() - $completedCount;
    ?>

    
    <div class="mt-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <div>
            <p class="text-xs font-semibold uppercase tracking-wide text-slate-400">
                Recruitment Batch Terpilih
            </p>

            <h2 class="mt-1 text-xl font-bold text-slate-800">
                <?php echo e($selectedBatch->name); ?>

            </h2>

            <p class="mt-1 text-sm text-slate-500">
                Posisi: <?php echo e($selectedBatch->position); ?>

            </p>
        </div>

        
        <div class="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div class="rounded-xl border border-slate-100 bg-slate-50 p-4">
                <p class="text-sm text-slate-500">Kandidat Lolos Screening</p>
                <p class="mt-2 text-2xl font-bold text-slate-800">
                    <?php echo e($applications->count()); ?>

                </p>
            </div>

            <div class="rounded-xl border border-slate-100 bg-slate-50 p-4">
                <p class="text-sm text-slate-500">Jumlah Kriteria Aktif</p>
                <p class="mt-2 text-2xl font-bold text-slate-800">
                    <?php echo e($criteria->count()); ?>

                </p>
            </div>

            <div class="rounded-xl border border-slate-100 bg-slate-50 p-4">
                <p class="text-sm text-slate-500">Progres Penilaian</p>
                <p class="mt-2 text-2xl font-bold text-indigo-600">
                    <?php echo e($completedCount); ?>/<?php echo e($applications->count()); ?>

                </p>
                <p class="mt-1 text-xs text-slate-500">
                    <?php echo e($completedCount); ?> lengkap · <?php echo e($incompleteCount); ?> belum lengkap
                </p>
            </div>
        </div>
    </div>

    
    <div class="mt-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <div class="mb-4">
            <h3 class="text-lg font-semibold text-slate-800">Daftar Kriteria</h3>
            <p class="mt-1 text-sm text-slate-500">
                Kriteria aktif yang digunakan untuk menilai kandidat.
            </p>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="mb-3 flex flex-col gap-2 rounded-lg border border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <p class="font-semibold text-slate-800">
                        <?php echo e($criterion->criterion_code); ?> - <?php echo e($criterion->name); ?>

                    </p>

                    <span class="mt-1 inline-flex rounded-full px-2.5 py-1 text-xs font-semibold
                        <?php echo e($criterion->attribute === 'benefit'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-amber-100 text-amber-700'); ?>">
                        <?php echo e(ucfirst($criterion->attribute)); ?>

                    </span>
                </div>

                <div class="text-sm font-bold text-slate-700">
                    <?php echo e(number_format((float) $criterion->weight, 2, ',', '.')); ?>%
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="rounded-lg bg-amber-50 p-4 text-sm text-amber-700">
                Belum ada kriteria aktif pada batch ini.
            </div>
        <?php endif; ?>
    </div>

    
    <div class="mt-6 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-200 p-5">
            <h3 class="text-lg font-semibold text-slate-800">
                Matriks Penilaian Kandidat
            </h3>
            <p class="mt-1 text-sm text-slate-500">
                Masukkan nilai setiap kandidat berdasarkan kriteria yang tersedia.
            </p>
        </div>

        <?php if($applications->isNotEmpty() && $criteria->isNotEmpty()): ?>

            
            <div class="hidden lg:block">
                <form method="POST"
                      action="<?php echo e(route('candidate-assessments.store', $selectedBatch)); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="p-4">
                        <table class="w-full table-fixed text-left text-sm">
                            <thead class="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                                <tr>
                                    <th class="w-[20%] px-3 py-4">Kandidat</th>

                                    <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="px-2 py-4 text-center">
                                            <div class="break-words font-bold text-slate-700">
                                                <?php echo e($criterion->criterion_code); ?>

                                            </div>
                                            <div class="mt-1 break-words text-xs font-medium normal-case text-slate-600">
                                                <?php echo e($criterion->name); ?>

                                            </div>
                                            <div class="mt-1 text-[11px] font-normal normal-case text-slate-400">
                                                <?php echo e(ucfirst($criterion->attribute)); ?> · <?php echo e(number_format((float) $criterion->weight, 2)); ?>%
                                            </div>
                                        </th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <th class="w-[12%] px-2 py-4 text-center">Progres</th>
                                </tr>
                            </thead>

                            <tbody class="divide-y divide-slate-100">
                                <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $filledCount = $application->assessments
                                            ->whereIn('recruitment_criterion_id', $criterionIds)
                                            ->count();

                                        $isComplete = $criterionIds->isNotEmpty()
                                            && $filledCount === $criterionIds->count();
                                    ?>

                                    <tr class="align-top transition hover:bg-slate-50">
                                        <td class="break-words px-3 py-4">
                                            <p class="font-semibold text-slate-800">
                                                <?php echo e($application->candidate->full_name); ?>

                                            </p>
                                            <p class="mt-1 text-xs text-slate-500">
                                                <?php echo e($application->candidate->candidate_code); ?>

                                            </p>
                                        </td>

                                        <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $assessment = $application->assessments
                                                    ->firstWhere('recruitment_criterion_id', $criterion->id);
                                            ?>

                                            <td class="px-2 py-4">
                                                <input
                                                    type="number"
                                                    name="scores[<?php echo e($application->id); ?>][<?php echo e($criterion->id); ?>]"
                                                    value="<?php echo e(old(
                                                        'scores.' . $application->id . '.' . $criterion->id,
                                                        $assessment?->score
                                                    )); ?>"
                                                    min="<?php echo e($criterion->attribute === 'cost' ? '0.01' : '0'); ?>"
                                                    step="0.01"
                                                    placeholder="Nilai"
                                                    class="w-full min-w-0 rounded-lg border border-slate-300 px-2 py-2 text-center text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                                                >

                                                <?php $__errorArgs = ["scores.{$application->id}.{$criterion->id}"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p class="mt-1 break-words text-xs text-red-600">
                                                        <?php echo e($message); ?>

                                                    </p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <td class="px-2 py-4 text-center">
                                            <?php if($isComplete): ?>
                                                <span class="inline-flex rounded-full bg-green-100 px-2 py-1 text-xs font-semibold text-green-700">
                                                    Lengkap
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex rounded-full bg-amber-100 px-2 py-1 text-xs font-semibold text-amber-700">
                                                    <?php echo e($filledCount); ?>/<?php echo e($criterionIds->count()); ?>

                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="flex justify-end border-t border-slate-100 p-5">
                        <button type="submit"
                                class="w-full rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700 sm:w-auto">
                            Simpan Seluruh Penilaian
                        </button>
                    </div>
                </form>
            </div>

            
            <div class="space-y-3 p-4 lg:hidden">
                <form method="POST"
                      action="<?php echo e(route('candidate-assessments.store', $selectedBatch)); ?>">
                    <?php echo csrf_field(); ?>

                    <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $filledCount = $application->assessments
                                ->whereIn('recruitment_criterion_id', $criterionIds)
                                ->count();

                            $isComplete = $criterionIds->isNotEmpty()
                                && $filledCount === $criterionIds->count();
                        ?>

                        <details class="group mb-3 rounded-xl border border-slate-200 bg-white">
                            <summary class="flex cursor-pointer list-none items-center justify-between gap-3 p-4">
                                <div class="min-w-0">
                                    <p class="truncate font-semibold text-slate-800">
                                        <?php echo e($application->candidate->full_name); ?>

                                    </p>
                                    <p class="mt-1 text-xs text-slate-500">
                                        <?php echo e($application->candidate->candidate_code); ?>

                                    </p>

                                    <div class="mt-2">
                                        <?php if($isComplete): ?>
                                            <span class="inline-flex rounded-full bg-green-100 px-2.5 py-1 text-xs font-semibold text-green-700">
                                                Lengkap
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex rounded-full bg-amber-100 px-2.5 py-1 text-xs font-semibold text-amber-700">
                                                <?php echo e($filledCount); ?>/<?php echo e($criterionIds->count()); ?> Terisi
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <span class="shrink-0 text-slate-400 transition group-open:rotate-180">
                                    ▼
                                </span>
                            </summary>

                            <div class="space-y-4 border-t border-slate-100 p-4">
                                <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $assessment = $application->assessments
                                            ->firstWhere('recruitment_criterion_id', $criterion->id);
                                    ?>

                                    <div>
                                        <div class="mb-2 flex flex-wrap items-center justify-between gap-2">
                                            <div>
                                                <p class="text-sm font-semibold text-slate-800">
                                                    <?php echo e($criterion->criterion_code); ?> - <?php echo e($criterion->name); ?>

                                                </p>
                                                <p class="mt-1 text-xs text-slate-500">
                                                    <?php echo e(ucfirst($criterion->attribute)); ?>

                                                    · Bobot <?php echo e(number_format((float) $criterion->weight, 2, ',', '.')); ?>%
                                                </p>
                                            </div>
                                        </div>

                                        <input
                                            type="number"
                                            name="scores[<?php echo e($application->id); ?>][<?php echo e($criterion->id); ?>]"
                                            value="<?php echo e(old(
                                                'scores.' . $application->id . '.' . $criterion->id,
                                                $assessment?->score
                                            )); ?>"
                                            min="<?php echo e($criterion->attribute === 'cost' ? '0.01' : '0'); ?>"
                                            step="0.01"
                                            placeholder="Masukkan nilai"
                                            class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                                        >

                                        <?php $__errorArgs = ["scores.{$application->id}.{$criterion->id}"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="mt-1 text-xs text-red-600">
                                                <?php echo e($message); ?>

                                            </p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </details>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="sticky bottom-0 -mx-4 border-t border-slate-200 bg-white p-4">
                        <button type="submit"
                                class="w-full rounded-lg bg-indigo-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-700">
                            Simpan Seluruh Penilaian
                        </button>
                    </div>
                </form>
            </div>

        <?php elseif($applications->isEmpty()): ?>
            <div class="p-6">
                <div class="rounded-lg bg-amber-50 p-4 text-sm text-amber-700">
                    Belum ada kandidat yang lolos administrative screening.
                </div>
            </div>
        <?php else: ?>
            <div class="p-6">
                <div class="rounded-lg bg-amber-50 p-4 text-sm text-amber-700">
                    Belum ada kriteria aktif untuk batch ini.
                </div>
            </div>
        <?php endif; ?>
    </div>

<?php else: ?>

    
    <div class="mt-6 rounded-xl border border-dashed border-slate-300 bg-white px-5 py-12 text-center shadow-sm sm:px-8">
        <div class="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-indigo-50">
            <span class="text-2xl text-indigo-600">✎</span>
        </div>

        <h3 class="mt-4 text-lg font-semibold text-slate-800">
            Pilih Recruitment Batch
        </h3>

        <p class="mx-auto mt-2 max-w-md text-sm leading-relaxed text-slate-500">
            Pilih Recruitment Batch terlebih dahulu melalui dropdown di atas,
            kemudian klik Tampilkan untuk melihat daftar kandidat dan mengisi penilaian.
        </p>
    </div>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\HireWise\resources\views/candidate-assessments/index.blade.php ENDPATH**/ ?>