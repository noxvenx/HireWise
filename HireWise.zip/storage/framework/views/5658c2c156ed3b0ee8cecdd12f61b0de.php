<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> - HireWise</title>

    <link
        rel="icon"
        type="image/png"
        href="<?php echo e(asset('favicon.png')); ?>"
    >

    <style>
    .sidebar-nav {
        scrollbar-width: none;
        -ms-overflow-style: none;
    }

    .sidebar-nav::-webkit-scrollbar {
        display: none;
    }
    </style>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="min-h-screen bg-slate-50 text-slate-800 antialiased">

    <div class="min-h-screen md:flex">

        
        <button
            id="sidebar-overlay"
            type="button"
            aria-label="Tutup navigasi"
            class="fixed inset-0 z-40 hidden bg-slate-950/50 backdrop-blur-sm md:hidden">
        </button>

        
        <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="min-w-0 flex-1">

            <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <main class="p-4 sm:p-6 lg:p-8">

                
                <?php if(session('success')): ?>
                    <div class="mb-6 flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 shadow-sm">
                        <span class="font-bold">✓</span>
                        <span><?php echo e(session('success')); ?></span>
                    </div>
                <?php endif; ?>

                
                <?php if(session('error')): ?>
                    <div class="mb-6 flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 shadow-sm">
                        <span class="font-bold">!</span>
                        <span><?php echo e(session('error')); ?></span>
                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>

            </main>
        </div>
    </div>

    
    <?php echo $__env->make('partials.delete-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const sidebar = document.getElementById('app-sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            const openButton = document.getElementById('sidebar-toggle');
            const closeButton = document.getElementById('sidebar-close');

            if (!sidebar || !overlay || !openButton) return;

            function openSidebar() {
                sidebar.classList.remove('-translate-x-full');
                overlay.classList.remove('hidden');
                document.body.classList.add('overflow-hidden');
                openButton.setAttribute('aria-expanded', 'true');
            }

            function closeSidebar() {
                sidebar.classList.add('-translate-x-full');
                overlay.classList.add('hidden');
                document.body.classList.remove('overflow-hidden');
                openButton.setAttribute('aria-expanded', 'false');
            }

            openButton.addEventListener('click', openSidebar);
            overlay.addEventListener('click', closeSidebar);

            if (closeButton) {
                closeButton.addEventListener('click', closeSidebar);
            }

            sidebar.querySelectorAll('[data-sidebar-link]').forEach(function (link) {
                link.addEventListener('click', function () {
                    if (window.innerWidth < 768) closeSidebar();
                });
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth >= 768) {
                    closeSidebar();
                }
            });

            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape') closeSidebar();
            });
        });
    </script>

</body>
</html><?php /**PATH C:\laragon\www\HireWise\resources\views/layouts/app.blade.php ENDPATH**/ ?>